-- name: Firstie Practice
-- description: 
-- incompatible: romhack

gLevelValues.entryLevel = LEVEL_CASTLE_GROUNDS

camera_set_use_course_specific_settings(false)

function no_fall_damage(m)
 m.peakHeight = m.pos.y
end
hook_event(HOOK_MARIO_UPDATE, no_fall_damage)

